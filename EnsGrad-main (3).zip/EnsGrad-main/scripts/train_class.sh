

python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.01_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.01_dropout_0.5_wmax_3.log
echo 1 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3.log
echo 2 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3.log
echo 3 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3.log
echo 4 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3.log
echo 5 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3.log
echo 6 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.01_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.01_dropout_0.5_wmax_3.log
echo 7 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.01_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.01_dropout_0.3_wmax_3.log
echo 8 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3.log
echo 9 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3.log
echo 10 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3.log
echo 11 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3.log
echo 12 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3.log
echo 13 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.01_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.01_dropout_0.3_wmax_3.log
echo 14 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.01_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.01_dropout_0.7_wmax_3.log
echo 15 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3.log
echo 16 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3.log
echo 17 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3.log
echo 18 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3.log
echo 19 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3.log
echo 20 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.01_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.01_dropout_0.7_wmax_3.log
echo 21 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.001_dropout_0.5_wmax_3.log
echo 22 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3.log
echo 23 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3.log
echo 24 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3.log
echo 25 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3.log
echo 26 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3.log
echo 27 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.001_dropout_0.5_wmax_3.log
echo 28 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.001_dropout_0.3_wmax_3.log
echo 29 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3.log
echo 30 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3.log
echo 31 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3.log
echo 32 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3.log
echo 33 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3.log
echo 34 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.001_dropout_0.3_wmax_3.log
echo 35 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.001_dropout_0.7_wmax_3.log
echo 36 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3.log
echo 37 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3.log
echo 38 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3.log
echo 39 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3.log
echo 40 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3.log
echo 41 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.001_dropout_0.7_wmax_3.log
echo 42 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0005_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0005_dropout_0.5_wmax_3.log
echo 43 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3.log
echo 44 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3.log
echo 45 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3.log
echo 46 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3.log
echo 47 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3.log
echo 48 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0005_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0005_dropout_0.5_wmax_3.log
echo 49 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0005_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0005_dropout_0.3_wmax_3.log
echo 50 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3.log
echo 51 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3.log
echo 52 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3.log
echo 53 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3.log
echo 54 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3.log
echo 55 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0005_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0005_dropout_0.3_wmax_3.log
echo 56 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0005_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0005_dropout_0.7_wmax_3.log
echo 57 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3.log
echo 58 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3.log
echo 59 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3.log
echo 60 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3.log
echo 61 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3.log
echo 62 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0005_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0005_dropout_0.7_wmax_3.log
echo 63 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0001_dropout_0.5_wmax_3.log
echo 64 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3.log
echo 65 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3.log
echo 66 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3.log
echo 67 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3.log
echo 68 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3.log
echo 69 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0001_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0001_dropout_0.5_wmax_3.log
echo 70 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0001_dropout_0.3_wmax_3.log
echo 71 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3.log
echo 72 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3.log
echo 73 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3.log
echo 74 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3.log
echo 75 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3.log
echo 76 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0001_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0001_dropout_0.3_wmax_3.log
echo 77 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_0.0001_dropout_0.7_wmax_3.log
echo 78 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3.log
echo 79 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3.log
echo 80 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3.log
echo 81 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3.log
echo 82 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3.log
echo 83 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0001_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_0.0001_dropout_0.7_wmax_3.log
echo 84 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_5e-05_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_5e-05_dropout_0.5_wmax_3.log
echo 85 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3.log
echo 86 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3.log
echo 87 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3.log
echo 88 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3.log
echo 89 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3.log
echo 90 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_5e-05_dropout_0.5_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_5e-05_dropout_0.5_wmax_3.log
echo 91 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_5e-05_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_5e-05_dropout_0.3_wmax_3.log
echo 92 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3.log
echo 93 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3.log
echo 94 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3.log
echo 95 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3.log
echo 96 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3.log
echo 97 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_5e-05_dropout_0.3_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_5e-05_dropout_0.3_wmax_3.log
echo 98 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32_32.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_5e-05_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32_32_lr_5e-05_dropout_0.7_wmax_3.log
echo 99 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3.log
echo 100 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3.log
echo 101 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x2_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3.log
echo 102 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_64x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3.log
echo 103 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3.log
echo 104 out of 90 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/classification/seq_32x1_16_filt3_nopool.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 >~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_5e-05_dropout_0.7_wmax_3.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/classification/seq_32x1_16_filt3_nopool_lr_5e-05_dropout_0.7_wmax_3.log
echo 105 out of 90 done
