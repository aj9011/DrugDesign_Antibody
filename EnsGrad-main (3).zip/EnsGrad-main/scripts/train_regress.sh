

python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 1 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 2 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 3 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 4 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 5 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 6 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 7 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 8 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 9 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 10 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 11 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 12 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 13 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 14 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 15 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 16 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 17 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 18 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 19 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 20 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 21 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 22 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 23 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 24 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 25 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 26 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 27 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 28 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 29 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 30 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 31 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 32 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 33 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 34 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 35 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 36 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 37 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 38 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 39 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 40 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 41 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 42 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 43 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 44 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 45 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 46 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 47 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 48 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 49 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 50 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 51 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 52 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 53 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 54 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 55 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 56 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 57 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 58 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 59 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 60 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 61 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 62 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 63 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 64 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 65 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 66 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 67 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 68 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 69 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 70 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 71 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 72 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 73 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 74 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 75 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 76 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 77 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_absolute_error.log
echo 78 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 79 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 80 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 81 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 82 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 83 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_absolute_error.log
echo 84 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 85 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 86 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 87 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 88 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 89 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_absolute_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_absolute_error.log
echo 90 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log
echo 91 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log
echo 92 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log
echo 93 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log
echo 94 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log
echo 95 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_log_cosh.log
echo 96 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log
echo 97 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log
echo 98 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log
echo 99 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log
echo 100 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log
echo 101 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_log_cosh.log
echo 102 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log
echo 103 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log
echo 104 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log
echo 105 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log
echo 106 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log
echo 107 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_log_cosh.log
echo 108 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 109 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 110 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 111 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 112 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 113 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 114 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 115 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 116 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 117 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 118 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 119 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 120 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 121 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 122 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 123 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 124 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 125 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 126 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log
echo 127 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log
echo 128 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log
echo 129 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log
echo 130 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log
echo 131 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_log_cosh.log
echo 132 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log
echo 133 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log
echo 134 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log
echo 135 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log
echo 136 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log
echo 137 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_log_cosh.log
echo 138 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log
echo 139 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log
echo 140 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log
echo 141 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log
echo 142 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log
echo 143 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_log_cosh.log
echo 144 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 145 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 146 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 147 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 148 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 149 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_log_cosh.log
echo 150 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 151 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 152 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 153 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 154 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 155 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_log_cosh.log
echo 156 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 157 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 158 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 159 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 160 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 161 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_log_cosh.log
echo 162 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log
echo 163 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log
echo 164 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log
echo 165 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log
echo 166 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log
echo 167 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_log_cosh.log
echo 168 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log
echo 169 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log
echo 170 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log
echo 171 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log
echo 172 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log
echo 173 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_log_cosh.log
echo 174 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log
echo 175 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log
echo 176 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log
echo 177 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log
echo 178 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log
echo 179 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type log_cosh >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_log_cosh.log
echo 180 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 181 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 182 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 183 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 184 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 185 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 186 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 187 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 188 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 189 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 190 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 191 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 192 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 193 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 194 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 195 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 196 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 197 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.01 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.01_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 198 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 199 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 200 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 201 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 202 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 203 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 204 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 205 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 206 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 207 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 208 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 209 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 210 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 211 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 212 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 213 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 214 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 215 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 216 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 217 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 218 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 219 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 220 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 221 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 222 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 223 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 224 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 225 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 226 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 227 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 228 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 229 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 230 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 231 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 232 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 233 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0005 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0005_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 234 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 235 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 236 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 237 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 238 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 239 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 240 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 241 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 242 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 243 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 244 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 245 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 246 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 247 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 248 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 249 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 250 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 251 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 0.0001 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_0.0001_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 252 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 253 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 254 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 255 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 256 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 257 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.5 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.5_wmax_3_loss_mean_squared_error.log
echo 258 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 259 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 260 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 261 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 262 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 263 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.3 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.3_wmax_3_loss_mean_squared_error.log
echo 264 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32_32.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32_32_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 265 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 266 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x1_16_filt3.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x1_16_filt3_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 267 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_32x2_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_32x2_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 268 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_64x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_64x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 269 out of 270 done
python ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression/seq_emb_32x1_16.py --lr 5e-05 --dropout 0.7 --w_maxnorm 3 --loss_type mean_squared_error >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log 2>&1
echo logs: ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/seq_emb_32x1_16_lr_5e-05_dropout_0.7_wmax_3_loss_mean_squared_error.log
echo 270 out of 270 done
