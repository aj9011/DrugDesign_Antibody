import multiprocessing
import subprocess

base_logs_dir ='/mnt/disk1/jhbyun/DrugDesign/antibody-2019/logs'

iteration_list = [10, 20, 30, 40, 50, 60, 70]
stepsize_list = [0.005, 0.0005, 0.001, 5e-04, 1e-04, 5e-05]
model_list = {'reg': ['seq_32x1_16', 'seq_64x1_16', 'seq_32x2_16', 'seq_32_32', 'seq_32x1_16_filt3', 'seq_emb_32x1_16'],
              'class': ['seq_32_32', 'seq_32x1_16', 'seq_32x1_16_4class', 'seq_32x1_16_filt3',
                        'seq_32x1_16_filt3_nopool', 'seq_32x2_16', 'seq_64x1_16',
                        'seq_emb_32x1_16']}

script_list = []
i = 0

for iteration in iteration_list:
    for stepsize in stepsize_list:
        for each_task in ['reg', 'class']:
            for each_model in model_list[each_task]:
                tmp_script = f'\nCUDA_VISIBLE_DEVICES=-1 python codeocean/utils/single_opt.py --architecture {each_model} --task {each_task} --iteration {iteration} --stepsize {stepsize} --saveh5 1'
                # script += f'\npython single_opt.py --architecture {each_model} --task {each_task}--iteration {iteration} --stepsize {stepsize}  --saveh5 1'
                tmp_script += f' >{base_logs_dir}/{each_task}/single_opt_{each_model}_iteration_{iteration}_stepsize_{stepsize}.log 2>&1'
                script_list.append(tmp_script)
                i += 1

print("Total Number of Gradient Ascent to run = ", i)


def process_line(line_command):
    subprocess.check_call(line_command, shell=True)


num_cpu = 16
job_pool = multiprocessing.Pool(num_cpu)
job_pool.map(process_line, script_list)


# cd /home/jhbyun/ResearchProjects/antibody-2019/
# PYTHONPATH=. python ascent_models.py
