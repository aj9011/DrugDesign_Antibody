import os

script = 'cd ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression\n'
os.makedirs('/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/scripts', exist_ok=True)
os.makedirs('/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/checkpoint/regression', exist_ok=True)

lr_list = [0.01, 1e-3, 5e-4, 1e-4, 5e-5]
dropout_list = [0.5, 0.3, 0.7]
# w_max_list = [2, 3, 5, 7]
wmax = 3

loss_list = ['mean_absolute_error', 'log_cosh', 'mean_squared_error']
i = 0
n_workers = 5
tot_N = len(lr_list) * len(dropout_list) * len(loss_list) * 6
list_of_5 = list(range(n_workers, tot_N*10, n_workers))

for loss in loss_list:
    for lr in lr_list:
        for dropout in dropout_list:
            for model in ['seq_32_32', 'seq_32x1_16', 'seq_32x1_16_filt3', 'seq_32x2_16', 'seq_64x1_16',
                          'seq_emb_32x1_16']:
                script += f'\npython {model}.py --lr {lr} --dropout {dropout} --w_maxnorm {wmax} --loss_type {loss}'
                # script += f'\nCUDA_VISIBLE_DEVICES=-1 python {model}.py --lr {lr} --dropout {dropout} --w_maxnorm {wmax} --loss_type {loss}'
                script += f' >~/ResearchProjects/DrugDesign/antibody-2019/logs/regression/{model}_lr_{lr}_dropout_{dropout}_wmax_{wmax}_loss_{loss}.log 2>&1'
                # if i not in list_of_5:
                #     script += ' &'
                # else:
                #     script += ' &&'
                # script += f'\necho {model}_lr_{lr}_dropout_{dropout}_wmax_{wmax}_loss_{loss}'
                if i in list_of_5:
                    script += f'\necho {i+1} out of {tot_N} done'
                i += 1
print(script)
# run
# mkdir ~/ResearchProjects/DrugDesign/antibody-2019/logs
# mkdir ~/ResearchProjects/DrugDesign/antibody-2019/logs/regression
# cd ~/ResearchProjects/DrugDesign/antibody-2019 && python train_regression.py > ./scripts/train_regress.sh && cd scripts && chmod u+x ./train_regress.sh
# bash ./train_regress.sh


# to check
# cd ~/ResearchProjects/DrugDesign/antibody-2019
# python codeocean/utils/regression/seq_32x1_16_filt3.py





