import subprocess
import pdb
import os
import numpy as np
import h5py
from keras.models import model_from_json
import json
from os.path import join


BASE_DIR2SAVE = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/checkpoint'
BASE_SEEDDIR = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/seed_seq'
base = BASE_DIR2SAVE
arc = 'seq_32_32'

architecture_file = join(base, arc + '.txt')
weight_file = join(base, arc + '.h5')

with open(architecture_file, "r") as f:
    json_file = json.load(f)

model = model_from_json(json_file)
del json_file

model.load_weights(weight_file)

# files = subprocess.check_output('ls ' + os.path.join(BASE_SEEDDIR, 'train.h5.batch*'), shell=True).split('\n')[:-1]
inputdir = BASE_SEEDDIR
files = os.listdir(inputdir)
files = [os.path.join(inputdir, f) for f in files]

layer_size=model.layers[0].input_shape
input_all=np.asarray([]).reshape((0,layer_size[1],layer_size[2],layer_size[3]))

for batchfile in files:
    fi = h5py.File(batchfile, 'r')
    dataset = np.asarray(fi['data'])
    label = np.asarray(fi['label'])
    label = label[:, 0]
    input_all = np.append(input_all, dataset, axis=0)
    
pdb.set_trace()