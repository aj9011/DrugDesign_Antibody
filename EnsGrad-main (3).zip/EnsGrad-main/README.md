# antibody-2019

Code for the paper:
Antibody Complementarity Determining Region Design Using High-Capacity Machine Learning

Copyright by the Massachusetts Institute of Technology.  All rights reserved.
