'''Copyright by the Massachusetts Institute of Technology.  All rights reserved.'''
import h5py
from os.path import join,exists
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation,Flatten
from keras.layers.convolutional import Convolution2D,MaxPooling2D
from keras.optimizers import Adadelta,RMSprop
from hyperas.distributions import choice, uniform
from keras.callbacks import ModelCheckpoint
from sklearn.model_selection import train_test_split
from keras.constraints import maxnorm
import numpy as np
from keras import metrics
import os
from keras import metrics
import matplotlib.pyplot as plt
import keras

# seq_32x2_16

WHICH_CHANNELS = 'channels_last'
keras.backend.set_image_data_format(WHICH_CHANNELS)

DATASIZE= 20  # I think datasize refers to the length of sequence
BASE_DIR2SAVE = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/checkpoint/classification/'
RESULT_DIR2SAVE = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/Summary/classification/'

os.makedirs(RESULT_DIR2SAVE, exist_ok=True)


def reportAcc(results, bestaccfile, args):
    val_acc = results['val_acc']
    print('Hyperas:valid acc: ', val_acc)
    if not exists(bestaccfile):
        current = -float("inf")
    else:
        with open(bestaccfile) as f:
            current = float(f.readline().strip())
    if val_acc > current:
        with open(bestaccfile, 'w+') as f:
            f.write('%f\n' % val_acc)
            args_dict = args.__dict__
            for each_k in args_dict:
                f.write(f'{each_k} = {args_dict[each_k]}\n')
        return True
    else:
        return False


def save_model(model):
    json_model = model.to_json()
    
    os.makedirs(BASE_DIR2SAVE, exist_ok=True)
    
    json_file_name = os.path.join(BASE_DIR2SAVE, 'seq_32x2_16.txt')
    weight_file_name = os.path.join(BASE_DIR2SAVE, 'seq_32x2_16.h5')
    
    # Saving model architecture
    with open(json_file_name, "w+") as f:
        json.dump(json_model, f)
    
    model.save(weight_file_name)


def compareAcc(args, result):
    summary_txt = os.path.join(RESULT_DIR2SAVE, 'seq_32x2_16_summary.txt')
    with open(summary_txt, "a+") as f:
        args_dict = args.__dict__
        f.write("model = seq_32x2_16\n")
        for each_k in args_dict:
            f.write(f'{each_k} = {args_dict[each_k]}\n')
        for each_k in result:
            f.write(f'{each_k} = {result[each_k]}\n')
        f.write('\n\n')
        

def train(args):
    W_maxnorm = args.w_maxnorm
    DROPOUT = args.dropout
    
    model = Sequential()
    # model.add(Convolution2D(32, 1, 5, padding='same', input_shape=(20, 1, DATASIZE), activation='relu',
    #                         kernel_constraint=maxnorm(W_maxnorm)))
    model.add(Convolution2D(32, 5, 1, padding='same', input_shape=(20, 1, DATASIZE), activation='relu',
                            kernel_constraint=maxnorm(W_maxnorm)))
    if WHICH_CHANNELS == 'channels_last':
        model.add(MaxPooling2D(pool_size=(2, 1), strides=(2, 1)))
    elif WHICH_CHANNELS == 'channels_first':
        model.add(MaxPooling2D(pool_size=(1, 2), strides=(1, 2)))
    
    # model.add(Convolution2D(64, 1, 5, padding='same', activation='relu', kernel_constraint=maxnorm(W_maxnorm)))
    model.add(Convolution2D(64, 5, 1, padding='same', activation='relu', kernel_constraint=maxnorm(W_maxnorm)))

    if WHICH_CHANNELS == 'channels_last':
        model.add(MaxPooling2D(pool_size=(2, 1), strides=(2, 1)))
    elif WHICH_CHANNELS == 'channels_first':
        model.add(MaxPooling2D(pool_size=(1, 2), strides=(1, 2)))
    
    model.add(Flatten())
    
    model.add(Dense(16, activation='relu', kernel_constraint=maxnorm(W_maxnorm)))
    model.add(Dropout(DROPOUT))
    model.add(Dense(2,kernel_constraint=maxnorm(W_maxnorm)))
    model.add(Activation('softmax'))
    # model.add(Dense(1))
    
    myoptimizer = RMSprop(lr=args.lr, rho=0.9, epsilon=1e-06)
    model.compile(loss='binary_crossentropy',
                  optimizer=myoptimizer,
                  metrics=[
                      'accuracy'
                  ])

    callback = tf.keras.callbacks.EarlyStopping(monitor='val_loss', mode='min', patience=10)
    train_X, train_y = concat_all_data(data_path=args.data_path)
    valid_X, valid_y = concat_all_data(data_path=args.test_data_path)

    history = model.fit(train_X, train_y,
                        batch_size=100,
                        epochs=500,
                        callbacks=[callback],
                        verbose=2,
                        validation_data=(valid_X, valid_y))

    results = model.evaluate(valid_X, valid_y)

    val_loss, val_acc = results
    results = {'val_acc': val_acc}

    report_file = os.path.join(BASE_DIR2SAVE, 'seq_32x2_16_best_result.txt')
    save_model_flag = reportAcc(results, report_file, args)
    compareAcc(args, results)

    if save_model_flag:
        model.fit(valid_X, valid_y,
                  batch_size=100,
                  epochs=2)
        save_model(model)

    return


def custom_data(batchnum=14, data_path=''):
    base_folder = data_path
    batch_list = [os.path.join(base_folder, each_batch)
                  for each_batch in os.listdir(base_folder) if 'batch' in each_batch]
    batch_list = sorted(batch_list)
    
    for i in range(batchnum):
        data1f = h5py.File(batch_list[i], 'r')
        data1 = np.array(data1f['data'])
        label = np.array(data1f['label'])
        
        yield (data1, label)


def concat_data(batchnum=14, valid_num=13, data_path=''):
    base_folder = data_path
    train_data_list = []
    train_label_list = []
    valid_data = None
    valid_label = None
    
    batch_list = [os.path.join(base_folder, each_batch)
                  for each_batch in os.listdir(base_folder) if 'batch' in each_batch]
    batch_list = sorted(batch_list)
    
    for i in range(batchnum):
        if i != valid_num:
            data1f = h5py.File(batch_list[i], 'r')
            train_data_list.append(np.array(data1f['data']))
            train_label_list.append(np.array(data1f['label']))
        else:
            data1f = h5py.File(batch_list[i], 'r')
            valid_data = np.array(data1f['data'])
            valid_label = np.array(data1f['label'])
    
    return np.concatenate(train_data_list, axis=0), np.concatenate(train_label_list, axis=0), valid_data, valid_label


def concat_all_data(data_path=''):
    base_folder = data_path
    data_list = []
    label_list = []
    batch_list = [os.path.join(base_folder, each_batch)
                  for each_batch in os.listdir(base_folder) if 'batch' in each_batch]
    
    for i, file_name in enumerate(batch_list):
        data1f = h5py.File(file_name, 'r')
        data_list.append(np.array(data1f['data']))
        label_list.append(np.array(data1f['label']))
    
    return np.concatenate(data_list, axis=0), np.concatenate(label_list, axis=0)


if __name__ == "__main__":
    import pdb
    import os
    import json
    import tensorflow as tf
    
    # cd ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/regression
    # python seq_32x2_16.py
    import argparse

    # BASE_FOLDER = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/data/training data/Full regression/batch_data/train.h5.batch'
    # HOLDOUT = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/data/training data/Holdout-top4-percent/batch_data/train.h5.batch'
    CLASS_DATA = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/data/training data/Hold out classification/batch_data/'
    CLASS_VALID = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/data/training data/Hold out classification/test_batch_data/'

    parser = argparse.ArgumentParser()
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--w_maxnorm', type=float, default=3)
    parser.add_argument('--use_all4training', choices=[0, 1], default=1)
    args = parser.parse_args()

    args.data_path = CLASS_DATA
    args.test_path = CLASS_VALID

    result = train(args)