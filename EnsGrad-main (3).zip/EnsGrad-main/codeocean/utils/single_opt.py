'''Copyright by the Massachusetts Institute of Technology.  All rights reserved'''
import matplotlib as mpl
mpl.use('Agg')
# import matplotlib.pyplot as plt,pandas as pd
# from os import makedirs
import numpy as np, sys, h5py, argparse, subprocess
from os.path import join,dirname,basename,exists
from os import system
import os
import tensorflow as tf
from keras.models import model_from_json
from keras import backend as K
from tensorflow.keras import models
import json
import pdb
import keras

WHICH_CHANNEL = 'channels_last'
# WHICH_CHANNEL = 'channels_first'

keras.backend.set_image_data_format(WHICH_CHANNEL)

IsAnneal=True
avoidnc=True
buff_range=30
# constraint='l2'
constraint = None
amino=np.asarray(['I', 'L', 'V', 'F', 'M', 'C', 'A', 'G', 'P', 'T', 'S', 'Y', 'W', 'Q', 'N', 'H', 'E', 'D', 'K', 'R', 'X'])
L2coeff = 0.1
base_dir = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/data/'
mapper_dir = os.path.join(base_dir, 'mapper')


def modified_mat2oh(datain, not_padded, ):
	orig_seq = []
	not_padded = np.bool_(not_padded)  #
	if len(datain.shape) >= 4:
		onehot = datain.reshape(datain.shape[0], datain.shape[1], datain.shape[3])
	else:
		onehot = datain
	if WHICH_CHANNEL == 'channels_last':
		colind = np.argmax(onehot, axis=2)
	elif WHICH_CHANNEL == 'channels_first':
		colind = np.argmax(onehot, axis=1)
	else:
		raise ValueError
	for i in range(colind.shape[0]):
		temp = colind[i][not_padded[i]]  # sequence with paddings filtered out
		sequence=''.join(amino[temp])
		orig_seq.append(sequence)
	orig_seq = np.asarray(orig_seq)
	
	return orig_seq


def get_padded_mask(not_padded):
	# Need to convert into mask of shape (number_of_sequences, sequence_length, 1, word_dim) (i, j, 1, k)
	# which indicates whether i-th sequence's j-th position's k-th word embedding corresponds to padding
	padded_pos = ~not_padded  # shape == (number_of_sequences, sequence_length)
	expanded_pos = np.zeros((padded_pos.shape[0], padded_pos.shape[1], 1, 20))
	for i in range(padded_pos.shape[0]):
		for j in range(padded_pos.shape[1]):
			if WHICH_CHANNEL == 'channels_first':
				expanded_pos[i, :, :, j] = padded_pos[i, j]  # for word_dim=axis 1
			elif WHICH_CHANNEL == 'channels_last':
				expanded_pos[i, j, :, :] = padded_pos[i, j]  # for word_dim=axis 2
	
	return np.bool_(expanded_pos)  # shape == (number_of_sequences, sequence_length, 1, word_dim)


def iterate(input_tensor, model):
	with tf.GradientTape() as gtape:
		gtape.watch(input_tensor)
		score = model(input_tensor, training=False)  # score.shape == (2000, 1)
		if constraint == 'l2':
			final_score = score - L2coeff * K.sum((input_tensor ** 2))
		else:
			final_score = score
	grads = gtape.gradient(final_score, input_tensor)
	
	return grads, score, final_score


def get_mapper(mapper_dir=mapper_dir):
	mapper = {}
	with open(mapper_dir, 'r') as f:
		for x in f:
			line = x.strip().split()
			word = line[0]
			vec = [float(item) for item in line[1:]]
			mapper[word] = vec
	
	return mapper


def decode(input_tensor):
	
	if WHICH_CHANNEL == 'channels_first':
		not_padded = np.sum(input_tensor.reshape(
			input_tensor.shape[0],
			input_tensor.shape[1],
			input_tensor.shape[3]), axis=1)!=0

	elif WHICH_CHANNEL == 'channels_last':
		not_padded = np.sum(input_tensor.reshape(
			input_tensor.shape[0],
			input_tensor.shape[1],
			input_tensor.shape[3]), axis=2)!=0
	else:
		raise ValueError
	
	return modified_mat2oh(input_tensor, not_padded)


def iterate2(input_tensor, model):
	
	score = model(input_tensor)
	if constraint == 'l2':
		final_score = score - L2coeff * K.sum((input_tensor ** 2))
	else:
		final_score = score
	
	return score, final_score


def main(args):
	base = args.rootpath
	arc = args.architecture
	task = args.task
	if task == 'reg':
		tmp_folder = 'regression'
	elif task == 'class':
		tmp_folder = 'classification'
	else:
		raise ValueError('task must be either reg or class')
	
	architecture_file = join(base, tmp_folder, arc + '.txt')
	weight_file = join(base, tmp_folder, arc + '.h5')
	resultdir = join(args.resultdir, tmp_folder, arc)
	
	iteration = args.iteration
	step = args.stepsize
	os.makedirs(resultdir, exist_ok=True)
	inputdir = args.seed_dir
	task_type = args.task_type
	
	savename=join(resultdir,'input_gen'+str(iteration)+'-'+str(step))
	outname=join(resultdir,'genseq-'+str(iteration)+'-'+str(step)+'.tsv')
	
	#------parsing model layers----------
	with open(architecture_file, "r") as f:
		json_file = json.load(f)
	
	model = model_from_json(json_file)
	del json_file
	
	model.load_weights(weight_file)
	model._trainable = False
	
	# pdb.set_trace()
	# sample = tf.random.uniform((100, 20, 1, 20), minval=0., maxval=1.)
	# grads, _, _ = iterate(sample, model)
	
	layer_input = model.layers[0].input
	layer_size=model.layers[0].input_shape
	print("input size:", layer_size)
	if task_type=='reg':
		output_layer = model.layers[-1].output
	elif task_type=='class':
		output_layer = model.layers[-2].output
	#---------create h5py file----------
	if args.saveh5:
		f = h5py.File(savename,'w')
		grp =f.create_group("inputgen")
		grp2=f.create_group("track")
	#--------parse input file-----------
	input_all=np.asarray([]).reshape((0,layer_size[1],layer_size[2],layer_size[3]))
	# input_all = []
	if os.path.isdir(inputdir):
		files = os.listdir(inputdir)
		files = [os.path.join(inputdir, f) for f in files if not f.endswith('.txt')]
	else:
		files = [inputdir,]
	
	for batchfile in files:
		fi = h5py.File(batchfile, 'r')
		dataset = np.asarray(fi['data'])
		# dataset = np.array(fi['data'])
		# label=np.asarray(fi['label'])
		# label = np.array(fi['label'])
		# label=label[:,0]
		input_all=np.append(input_all,dataset,axis=0)
		# input_all.append(dataset)
	
	input_all = np.array(input_all)
	
	if args.saveh5:
		grp.create_dataset("orig_seq",data=input_all.reshape(input_all.shape[0],input_all.shape[1],input_all.shape[3]))
	
	best_map=np.asarray([]).reshape((0,layer_size[1],layer_size[2],layer_size[3]))
	record_all=np.asarray([]).reshape((0,layer_size[1],layer_size[2],layer_size[3]))
	record_seed=np.asarray([])#seed for each proposed sequence
	oh_seq=np.asarray([])
	record_act=np.asarray([])
	record_sact=np.asarray([])
	best_act=np.asarray([])
	init_act=np.asarray([])
	init_loss=np.asarray([])
	best_it = np.asarray([])
	orig_seq_list = np.asarray([])
	
	for batch in range(0,input_all.shape[0],2000):
		input_data=input_all[batch:min(batch+2000,input_all.shape[0])]
		datain=np.copy(input_data)
		tryi=input_data.shape[0]
		input_tensor = tf.convert_to_tensor(input_data, dtype=tf.float32)
		best_input =np.zeros(input_data.shape)
		record_all_seq=np.asarray([]).reshape(0,datain.shape[1],datain.shape[2],datain.shape[3])
		record_all_act=np.asarray([])
		record_all_orig=np.asarray([])
		record_seed_act=np.asarray([])
		convg_input=np.zeros(input_data.shape)
		best_activation = np.asarray([-1.0]*tryi)
		best_loss = np.asarray([-1000000000.0]*tryi)
		convg_activation = np.asarray([-10000.0]*tryi)
		best_iter = np.asarray([-1]*tryi)
		convg_iter=np.asarray([-1]*tryi)
		loss_track = []
		activation_track = []
		count=0
		
		activation_init, loss_init=iterate2(input_tensor, model)
		activation_init, loss_init = activation_init.numpy(), loss_init.numpy()
		
		init_act=np.append(init_act,activation_init[:,0],axis=0)
		init_loss=np.append(init_loss,loss_init[:,0],axis=0)
		holdcnt = np.asarray([0]*tryi)
		
		Initial_Mean_Act = np.mean(activation_init)
		
		lr=step
		print('')
		print('')
		print('---------------------------------------------------------------')
		print('Initial Average Enrichment Score = ', np.mean(activation_init))
		print('---------------------------------------------------------------')
		print('')
		print('')
		mask=np.array([False for i in range(tryi)])
		
		
		if WHICH_CHANNEL == 'channels_first':
			not_padded=np.sum(
				datain.reshape(
					datain.shape[0],
					datain.shape[1],
					datain.shape[3]),
				axis=1) != 0
		elif WHICH_CHANNEL == 'channels_last':
			not_padded = np.sum(
				datain.reshape(
					datain.shape[0],
					datain.shape[1],
					datain.shape[3]),
				axis=2) != 0  # modified from axis=2
		else:
			raise ValueError
			
		padded_mask = get_padded_mask(not_padded)
		
		record_trim=np.asarray([]).reshape(0,not_padded.shape[1])
		orig_seq = modified_mat2oh(datain, not_padded)
		orig_seq_list = np.append(orig_seq_list, orig_seq, axis=0)
		while True:
			for grow in range(iteration):
				input_tensor = tf.Variable(tf.convert_to_tensor(input_data, dtype=tf.float32))
				
				grads_value, _, _ = iterate(input_tensor, model)
				grads_value = grads_value.numpy()
				grads_value[mask,:,:,:]=0  # what is this for?
				
				# pdb.set_trace()
				if count>100:
					lr=max(step*(count-100)**(-0.2),1e-6)
				input_data += grads_value*lr
				input_data[padded_mask] = 0.0
			
			activation_all, loss_all = iterate2(input_tensor, model)
			activation_all, loss_all = activation_all.numpy(), loss_all.numpy()
			
			print('---------------------------------------------------')
			print('Iteration', count*iteration)
			print('Average Enrichment Score (Float Vector)', np.mean(activation_all))
			print('Number of sequences Converged', sum(mask))
			print(float(sum(mask))*100./2000, " % of sequences converged")
			onehot=input_data.reshape(input_data.shape[0], input_data.shape[1], input_data.shape[3])
			if WHICH_CHANNEL == 'channels_last':
				colrank = np.argsort(onehot, axis=2)
				colind=np.argmax(onehot, axis=2)  # changed to axis=1 since word dim = axis 1
			elif WHICH_CHANNEL == 'channels_first':
				colrank = np.argsort(onehot, axis=1)
				colind = np.argmax(onehot, axis=1)  # changed to axis=1 since word dim = axis 1
			else:
				raise ValueError
			oh=np.zeros(onehot.shape)
			# pdb.set_trace()
			# converting input_data (float vector) into one hot vector
			for x in range(onehot.shape[0]):
				for y in range(onehot.shape[1]):
					if avoidnc:
						if amino[colind[x,y]]=='N' or amino[colind[x,y]]=='C':
							if WHICH_CHANNEL == 'channels_first':
								colind[x, y] = colrank[x, -2, y]
							elif WHICH_CHANNEL == 'channels_last':
								colind[x, y] = colrank[x, y, -2]
							else:
								raise ValueError
							
					if WHICH_CHANNEL == 'channels_first':
						oh[x, colind[x, y], y] = 1.0
					elif WHICH_CHANNEL == 'channels_last':
						oh[x, y, colind[x, y]] = 1.0
			
			
			oh=oh.reshape(oh.shape[0],layer_size[1],layer_size[2],layer_size[3])
			oh[padded_mask]=0.0
			oh_activation, oh_loss = iterate2(oh.astype('float32'), model)
			oh_activation, oh_loss = oh_activation.numpy().reshape(-1), oh_loss.numpy().reshape(-1)
			
			print('Average Enrichment Score (One Hot Vector)', np.mean(oh_activation))
			print('---------------------------------------------------')
			activation_track.append(oh_activation)
			temp_act=np.copy(oh_activation)
			
			# pdb.set_trace()
			temp_act[mask]=-10000.0
			improve=(temp_act.reshape(-1)>best_activation.reshape(-1))
			
			if sum(improve)>0:  # each element in improve: either True or False
				best_activation[improve] = oh_activation[improve]
				best_input[improve,:,:,:] = oh[improve,:,:,:]
				record_all_orig=np.append(record_all_orig,orig_seq[improve],axis=0)
				activation_init = activation_init.reshape(-1)
				record_seed_act=np.append(record_seed_act,activation_init[improve],axis=0)
				record_all_seq=np.append(record_all_seq,oh[improve,:,:,:],axis=0)
				record_all_act=np.append(record_all_act,oh_activation[improve],axis=0)
				record_trim=np.append(record_trim, not_padded[improve,:],axis=0)
				best_iter[improve]=count
			holdcnt[improve]=0
			holdcnt[~improve]=holdcnt[~improve]+1
			mask=(holdcnt>=buff_range)
			if sum(mask)==tryi or count>1000:
				print('Initial Score ', Initial_Mean_Act)
				print('Converge at',count)
				print('Activation',np.mean(activation_all))
				print('Converged',sum(mask))
				print('Loss',np.mean(loss_all))
				print('Best score',np.mean(best_activation))
			
				out_seq = modified_mat2oh(record_all_seq, record_trim)
				oh_seq=np.append(oh_seq,out_seq,axis=0)
				
				break
			
			count+=1
		
		best_map=np.append(best_map,best_input,axis=0)
		best_act=np.append(best_act,best_activation,axis=0)
		best_it=np.append(best_it,best_iter,axis=0)
		record_all=np.append(record_all,record_all_seq,axis=0)
		record_act=np.append(record_act,record_all_act,axis=0)
		record_seed=np.append(record_seed,record_all_orig,axis=0)
		record_sact=np.append(record_sact,record_seed_act,axis=0)
		
	if args.saveh5:
		
		grp.create_dataset("best_seq",data=best_map)
		grp.create_dataset("onehot_matrix",data=record_all)
		
		encoding = lambda x: x.encode('utf-8')
		orig_seq_list = np.array(list(map(encoding, orig_seq_list)))
		oh_seq = np.array(list(map(encoding, oh_seq)))
		record_seed = np.array(list(map(encoding, record_seed)))
		
		grp2.create_dataset("init_act", data=init_act)
		grp2.create_dataset("init_loss", data=init_loss)
		grp2.create_dataset("original_sequence", data=orig_seq_list)  # *** TypeError: No conversion path for dtype: dtype('<U18')
		grp2.create_dataset("onehot_sequence", data=oh_seq)  # *** TypeError: No conversion path for dtype: dtype('<U32')
		grp2.create_dataset("seed_sequence",data=record_seed)  # *** TypeError: No conversion path for dtype: dtype('<U32')
		grp2.create_dataset("best_activation", data=best_act)
		grp2.create_dataset("all_activation", data=record_act)
		grp2.create_dataset("seed_activation", data=record_sact)
		f.close()
	
	tsv=np.concatenate((np.arange(oh_seq.shape[0]).reshape(oh_seq.shape[0],1),
						oh_seq.reshape(oh_seq.shape[0],1),
						record_seed.reshape(record_seed.shape[0],1),
						record_act.reshape(record_act.shape[0],1),
						record_sact.reshape(record_sact.shape[0],1)),axis=1)
	
	np.savetxt(outname,tsv,fmt='%s',delimiter='\t')
	
if __name__ == "__main__":
	BASE_DIR2SAVE = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/checkpoint'  # local path
	BASE_RESULTDIR = '/mnt/disk1/jhbyun/DrugDesign/antibody-2019/result'
	
	# BASE_SEEDDIR = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/data/training data/Holdout-top4-percent/batch_data'  # local path
	# BASE_SEEDDIR = '/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/filtered_seed_seq'  # need to embed the filtered_seed into h5 format
	BASE_SEEDDIR = "/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/data/training data/Full regression/batch_data"
	
	# cd ~/ResearchProjects/DrugDesign/antibody-2019/codeocean/utils/
	
	# python single_opt.py --architecture seq_32x1_16_filt3
	# CUDA_VISIBLE_DEVICES=-1 python single_opt.py --architecture seq_32x1_16_filt3 --iteration 70 --stepsize 1e-3  --saveh5 1
	
	# python single_opt.py --architecture seq_32_32 --iteration 10 --stepsize 1e-3  --saveh5 1
	
	# To run optimization on the filtered sequence
	# python single_opt.py --architecture seq_32_32 --iteration 30 --stepsize 1e-4  --saveh5 1 --seed_dir /home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/filtered_seed_seq --resultdir /home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/filtered_seed_result
	
	import shutil
	# shutil.rmtree('/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/result/seq_32x1_16_filt3', ignore_errors=True)
	# os.makedirs('/home/jhbyun/ResearchProjects/DrugDesign/antibody-2019/result/seq_32x1_16_filt3', exist_ok=True)
	parser = argparse.ArgumentParser()
	parser.add_argument('--rootpath', type=str, default=BASE_DIR2SAVE)
	parser.add_argument('--architecture', type=str, default='seq_32x1_16_filt3')
	parser.add_argument('--resultdir', type=str, default=BASE_RESULTDIR)
	parser.add_argument('--iteration', type=int, default=70)
	parser.add_argument('--stepsize', type=float, default=1e-4)
	parser.add_argument('--seed_dir', type=str, default=BASE_SEEDDIR)
	parser.add_argument('--task', type=str, default='reg', choices=['reg', 'class'])
	parser.add_argument('--saveh5', type=int, default=1)
	args = parser.parse_args()
	
	main(args)

